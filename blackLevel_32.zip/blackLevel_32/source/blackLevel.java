import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class blackLevel extends PApplet {

PImage img = null;
Arrangement arr;
int SWAPS = 2000;
int changeCutoffBy = 0;
int changeRoundBy = 0;

public void setup() {
  surface.setResizable(true);
  selectInput("Select an image:", "setImage");
  //img = loadImage("images/outline.jpg");
  arr = null;
}

public void setImage(File selection) {
  if (selection != null) {
    img = loadImage(selection.getAbsolutePath());
  } else {
    selectInput("Select an image:", "setImage");
  }
}

public void draw() {
  if (arr == null) {
    if (img != null) {
      arr = new Arrangement(img); 
    }
  } else {
    if (!keyPressed && changeCutoffBy != 0) {
      int cutoff = arr.changeCutoff(changeCutoffBy);
      println("Change by: " + changeCutoffBy + " Updated to: " + cutoff);
      changeCutoffBy = 0;
    }
    if (!keyPressed && changeRoundBy != 0) {
      int round = arr.changeRound(changeRoundBy);
      println("Change by: " + changeRoundBy + " Updated to: " + round);
      changeRoundBy = 0;
    }
    background(255);
    arr.draw();
  }
}

public void keyPressed() {
  if (key == CODED) {
    if (keyCode == UP) {
      changeCutoffBy += 1;
      println(changeCutoffBy);
    } else if (keyCode == DOWN) {
      changeCutoffBy -= 1;
      println(changeCutoffBy);
    } else if (keyCode == LEFT) {
      changeRoundBy -= 1;
      println(changeCutoffBy);
    } else if (keyCode == RIGHT) {
      changeRoundBy += 1;
      println(changeCutoffBy);
    }
  } else if (key == ' ') {
    println("Saved as: " + arr.save());
  } else if (key == '=') {
    arr.zoomIn();
  } else if (key == '-') {
    arr.zoomOut();
  }
}
class Arrangement {
  int h, w;
  
  int cutoff = 125;
  int round = 4;
  
  float dS;
  int now = 0;
  PImage img;
  PImage img2;
  PImage dispImg;
  boolean changedNow = false;
  
  final int WHITE = color(255);
  final int BLACK = color(0);
  
  public Arrangement(PImage img) {
    this.img = img;
    if (img.height == 0 || img.width == 0) {
      throw new RuntimeException("Image must have greater than 0 dimension");
    }
    h = img.height;
    w = img.width;
    dS = 1.0f;
    
    
    img2 = createImage(w, h, RGB);
    dispImg = createImage(w, h, RGB);
    // Don't change the cutoff, but filter through to the display Image
    changeCutoff(0);
  }
  
  public String save() {
    int fileNum = 0;
    
    File dir = new File(savePath("output"));
    dir.mkdir();
    String name = "output/"+fileNum+".png";
    File f = new File(savePath(name));
    while (f.exists()) {
      fileNum++;
      name = "output/"+fileNum+".png";
      f = new File(savePath(name));
    }
    dispImg.save(name);
    return name;
  }
  
  public void draw() {
    image(dispImg, 0, 0, w*dS, h*dS);
  }
  
  public void zoomOut() {
    dS = max(0.1f, dS-0.1f);
  }
  
  public void zoomIn() {
    dS = dS+0.1f;
  }
  
  public int changeCutoff(int a) {
    cutoff = min(max(0, cutoff + a), 256);
    img.loadPixels();
    for (int i=0; i < img.pixels.length; i++) {
      img2.pixels[i] = cutoff(img.pixels[i]) ? WHITE : BLACK;
    }
    img2.updatePixels();
    changeRound(0);
    return cutoff;
  }
  
  public int changeRound(int a) {
    round = min(max(0, round + a), 8);
    
    for (int i=0; i < h; i++) {
      for (int j=0; j < w; j++) {
        int px = img2.get(j, i);
        float frac = fracBlackNeighbors(j, i); 
        /*
        if (frac > round / 8.0) {
          dispImg.set(j, i, BLACK);
        } else if (frac > round / 8.0) {
          dispImg.set(j, i, WHITE);
        } else {
          dispImg.set(j, i, px);
        }
        */
        
        boolean change = false;
        if ((px == WHITE && frac > round / 8.0f) || (px == BLACK && (1 - frac) > round / 8.0f)) {
          change = true;
        }
        dispImg.set(j, i, (change == (px == WHITE)) ? BLACK : WHITE);
      }
    }
    
    return round;
  }
  
  private float fracBlackNeighbors(int x, int y) {
    int total = 0;
    float black = 0; 
    for (int i=y-1; i < y+2; i++) {
      for (int j=x-1; j < x+2; j++) {
        if (i != y && j != x && i > 0 && i < h && j > 0 && j < w) {
          total += 1;
          if (img2.get(j, i) == BLACK) {
            black += 1;
          }
        }
      }
    }
    return black / total;
  }
  
  private boolean cutoff(int c) {
    return red(c) + green(c) + blue(c) > cutoff*3;
  }
  
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "blackLevel" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
